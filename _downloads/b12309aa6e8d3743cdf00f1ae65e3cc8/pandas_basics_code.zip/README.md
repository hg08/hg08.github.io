# Pandas Basics - Code Package

This package accompanies the English Pandas Basics teaching notes.

## Contents

- `pandas_basics.ipynb`: executable Jupyter notebook
- `pandas_basics.md`: English Markdown export of the notebook
- `pandas_basics.tex`: English LaTeX teaching notes
- `requirements.txt`: Python package requirements
- `data/input1.csv`: small CSV input example
- `data/mydataset.csv`: small numerical dataset
- `data/wine.csv`: wine case-study dataset

## Setup on macOS and Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m jupyter lab pandas_basics.ipynb
```

## Setup on Windows PowerShell

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m jupyter lab pandas_basics.ipynb
```

Run these commands from this directory so the notebook can find `requirements.txt` and the `data/` folder. Use `deactivate` when you finish. Do not add `.venv` to the ZIP archive or to version control.

# Pandas Basics: From Tabular Data to Scientific Analysis

**Course context:** AI in Science - Foundations of Python Data Processing  
**Learning goals:** Understand Series, DataFrame, indexing, missing values, CSV input and output, grouped summaries, and a complete wine-data case study.

> These notes reorganize the original Pandas appendix and replace the removed `.ix` indexer with the Pandas 2.x interfaces `.loc` and `.iloc`.

## 0. Environment and Data Paths

Create an isolated Python environment before installing the required packages. Run these commands from the `pandas_basics_code` directory.

### macOS and Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m jupyter lab pandas_basics.ipynb
```

### Windows PowerShell

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m jupyter lab pandas_basics.ipynb
```

Use `deactivate` when you finish working. Do not add the `.venv` directory to the ZIP archive or to version control. The notebook automatically searches for the sample datasets in the current directory or in a `data/` subdirectory.

```python
from pathlib import Path
import numpy as np
import pandas as pd

print("pandas version:", pd.__version__)
DATA_DIR = Path("data") if Path("data").exists() else Path(".")
print("data directory:", DATA_DIR.resolve())
```

## 1. Series: Labeled One-Dimensional Data

A Series stores both **values** and an **index**. It behaves like a one-dimensional NumPy array combined with an ordered mapping.

```python
fibonacci = pd.Series([1, 1, 2, 3, 5], name="fibonacci")
fibonacci
```

```python
print("values:", fibonacci.to_numpy())
print("index:", fibonacci.index)

labeled = pd.Series([1, 1, 2, 3, 5], index=list("abcdf"), name="value")
labeled
```

Series supports vectorized calculations and Boolean filtering. Prefer these operations to explicit element-by-element loops.

```python
transformed = pd.DataFrame({
    "original": labeled,
    "square": labeled ** 2,
    "sine": np.sin(labeled),
})
transformed
```

```python
labeled[labeled < 3]
```

### 1.1 Creating a Series from a Dictionary and Handling Missing Values

When a requested index label is absent from the original dictionary, Pandas represents the missing value with `NaN`.

```python
income = {"Chengdu": 4000, "Shanghai": 6000, "Chongqing": 5000}
cities = ["Guangzhou", "Shenzhen", "Shanghai", "Chongqing"]
city_income = pd.Series(income, index=cities, name="income")
city_income.index.name = "city"
city_income
```

```python
pd.DataFrame({
    "income": city_income,
    "is_missing": city_income.isna(),
    "is_present": city_income.notna(),
})
```

### 1.2 Automatic Alignment by Index

Series operations align values by label before performing arithmetic. Labels present on only one side produce missing values unless a fill value is supplied explicitly.

```python
income_a = pd.Series({"Chengdu": 4000, "Shanghai": 6000, "Chongqing": 5000})
income_b = pd.Series({"Chengdu": 4200, "Shanghai": 6100, "Xiamen": 4800, "Taipei": 4900})

comparison = pd.DataFrame({
    "period_a": income_a,
    "period_b": income_b,
    "sum_default": income_a + income_b,
    "sum_missing_as_zero": income_a.add(income_b, fill_value=0),
})
comparison
```

## 2. DataFrame: Two-Dimensional Tabular Data

A DataFrame consists of named columns. Columns may have different data types, but they share the same row index.

```python
city_table = pd.DataFrame({
    "city": ["Chengdu", "Shanghai", "Xiamen", "Taipei"],
    "income": [4000, 6000, 4800, 4900],
    "population_million": [21.4, 24.9, 5.3, 2.5],
})
city_table
```

```python
city_table.info()
```

### 2.1 Selecting Rows and Columns with `[]`, `.loc`, and `.iloc`

- `df["column"]` selects one column by name.
- `.loc[row_labels, column_labels]` selects by labels.
- `.iloc[row_positions, column_positions]` selects by integer positions.

The `.ix` indexer used in older material has been removed from Pandas and should not be used.

```python
by_label = city_table.loc[1:2, ["city", "income"]]
by_position = city_table.iloc[:2, :2]
print("loc result:\n", by_label)
print("\niloc result:\n", by_position)
```

```python
high_income = city_table.loc[city_table["income"] >= 4900].copy()
high_income["income_per_million"] = (
    high_income["income"] / high_income["population_million"]
).round(1)
high_income
```

### 2.2 Modifying, Adding, and Dropping Columns

Use `.assign()` to add columns within a method chain and `.drop()` to remove rows or columns. Avoid chained assignment on filtered data; create an explicit copy first.

```python
city_enriched = (
    city_table
    .assign(income_index=lambda df: df["income"] / df["income"].mean())
    .sort_values("income", ascending=False)
    .reset_index(drop=True)
)
city_enriched
```

```python
city_enriched.drop(columns="population_million")
```

### 2.3 Building a DataFrame from Nested Dictionaries and Transposing It

```python
gdp = {
    "Chengdu": {"2000": 30, "2005": 45, "2010": 70},
    "Chongqing": {"2000": 25, "2005": 35, "2010": 60},
    "Xian": {"2000": 28, "2005": 48, "2010": 75},
}
gdp_frame = pd.DataFrame(gdp)
gdp_frame.index.name = "year"
gdp_frame.columns.name = "city"
print(gdp_frame)
print("\nTransposed:\n", gdp_frame.T)
```

## 3. Reindexing, Missing Values, and Sorting

The `reindex()` method changes label order and may introduce new labels. For ordered or time-dependent data, `ffill()` and `bfill()` can propagate neighboring values when that treatment is scientifically justified.

```python
colors_series = pd.Series(["blue", "yellow", "red"], index=[0, 2, 4])
filled = pd.DataFrame({
    "original": colors_series.reindex(range(6)),
    "forward_fill": colors_series.reindex(range(6)).ffill(),
    "backward_fill": colors_series.reindex(range(6)).bfill(),
})
filled
```

```python
measurements = pd.DataFrame({
    "sample": ["A", "B", "C", "D"],
    "temperature": [298.1, np.nan, 301.4, 299.8],
    "pressure": [1.01, 1.03, np.nan, 1.00],
})
print("missing counts:\n", measurements.isna().sum())
measurements.assign(
    temperature=lambda df: df["temperature"].fillna(df["temperature"].median()),
    pressure=lambda df: df["pressure"].fillna(df["pressure"].mean()),
)
```

## 4. Reading and Writing CSV Data

After reading a CSV file, inspect column names, data types, missing values, and row counts. For scientific datasets, also document the encoding, delimiter, units, and data source.

```python
input_data = pd.read_csv(DATA_DIR / "input1.csv")
input_data.head()
```

```python
custom_names = pd.read_csv(
    DATA_DIR / "input1.csv",
    header=None,
    names=["X1", "X2", "y"],
)
custom_names.head()
```

```python
dataset = pd.read_csv(DATA_DIR / "mydataset.csv")
print(dataset.head())
print("\nSummary:\n", dataset.describe(include="all"))
```

## 5. Case Study: Wine Data

The `wine.csv` dataset contains 178 observations, three classes, and several physicochemical features. The following analysis performs initial quality checks, grouped summaries, and feature ranking.

```python
wine = pd.read_csv(DATA_DIR / "wine.csv")
print("shape:", wine.shape)
print("missing values:", int(wine.isna().sum().sum()))
wine.head()
```

```python
wine[["Alcohol", "Malic.acid", "Mg", "Color.int", "Proline"]].describe().round(2)
```

```python
class_summary = (
    wine.groupby("Wine")
    .agg(
        samples=("Wine", "size"),
        alcohol_mean=("Alcohol", "mean"),
        color_mean=("Color.int", "mean"),
        proline_mean=("Proline", "mean"),
    )
    .round(2)
)
class_summary
```

```python
numeric_wine = wine.select_dtypes(include="number")
alcohol_correlations = (
    numeric_wine.corr()["Alcohol"]
    .drop("Alcohol")
    .sort_values(key=lambda s: s.abs(), ascending=False)
)
alcohol_correlations.head(6).round(3)
```

## 6. Method Chaining for a Reproducible Analysis Workflow

Combining filtering, derived variables, selection, grouping, and sorting in one expression reduces temporary variables and makes the analysis sequence explicit.

```python
top_samples = (
    wine
    .query("Alcohol >= 13")
    .assign(phenol_ratio=lambda df: df["Flavanoids"] / df["Phenols"])
    .loc[:, ["Wine", "Alcohol", "Phenols", "Flavanoids", "phenol_ratio"]]
    .sort_values(["Wine", "phenol_ratio"], ascending=[True, False])
    .groupby("Wine", group_keys=False)
    .head(3)
    .round(3)
)
top_samples
```

## 7. Summary and Exercises

1. Series and DataFrame provide **labeled data structures** with **automatic alignment**.
2. Use `.loc` for label-based selection and `.iloc` for position-based selection.
3. Inspect missing values with `isna()`, then choose deletion, imputation, interpolation, or modeling according to the scientific question.
4. After reading a CSV file, inspect `shape`, `head()`, `dtypes`, missing values, and descriptive statistics.
5. Use `groupby()`, `agg()`, and method chaining to build clear and reproducible analyses.

**Exercises**

- Calculate the median and interquartile range of `Alcohol` for each Wine class.
- Find the ten observations with the largest `Proline` values and compare their `Wine` class distribution.
- Save the grouped statistics as `wine_class_summary.csv`.

```python
exercise_summary = (
    wine.groupby("Wine")["Alcohol"]
    .agg(median="median", q1=lambda s: s.quantile(0.25), q3=lambda s: s.quantile(0.75))
    .assign(iqr=lambda df: df["q3"] - df["q1"])
    .round(3)
)
exercise_summary
```

# LaTeX Compilation

The file `pandas_basics.tex` contains the English LaTeX source for the teaching notes. It uses standard packages and can be compiled with pdfLaTeX:

```bash
pdflatex pandas_basics.tex
pdflatex pandas_basics.tex
```

The separate `pandas_basics_overleaf.zip` archive is the recommended package for direct import into Overleaf.

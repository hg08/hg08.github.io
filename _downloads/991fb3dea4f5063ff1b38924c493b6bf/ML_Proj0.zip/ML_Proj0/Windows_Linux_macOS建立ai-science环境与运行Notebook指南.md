# Windows、Linux 与 macOS 建立 `ai-science` 环境及运行 Notebook 指南

本指南用于在 Windows、Linux 和 macOS 上建立同名的 `ai-science` Conda 环境，并运行《AI在科学中的应用》课程中的 `.ipynb` 文件等代码。

配套文件：

- `environment-ai-science.yml`：推荐的跨平台环境定义；
- `check_ai_science_environment.py`：安装完成后的自动检查程序。

当前课程环境以 Python 3.12 为基础，核心库包括 NumPy、Pandas、SciPy、Matplotlib、scikit-learn、JupyterLab、ipykernel，以及材料科学示例使用的 `mp-api` 和 `pymatgen`。后面需要用到库，可以自行添加。

## 1. 四个概念

### 1.1 Conda 环境

Conda 环境是一套彼此隔离的 Python 解释器和软件包。例如：

```text
base          Conda 自身所在的基础环境
ai-science    本课程使用的 Python 环境 
```

在终端中看到 `(ai-science)`，表示当前命令会使用该环境中的 Python：

```text
(ai-science) ...>
```

### 1.2 Python 解释器

不同环境有不同的 `python`。检查当前使用的是哪一个：

```bash
python --version
python -c "import sys; print(sys.executable)"
```

### 1.3 Jupyter Kernel

Notebook 的代码不是由编辑器本身运行，而是由 Kernel 运行。即使已经打开了正确的文件，如果 Kernel 选错，仍会出现“已经安装但无法导入”的问题。

在 Notebook 中运行以下代码可以确认 Kernel：

```python
import sys
print(sys.executable)
```

输出路径应包含 `ai-science`。

### 1.4 编辑器、终端与运行环境

- **VS Code**：适合统一管理 `.py`、`.ipynb`、Markdown 和课程文件；推荐。
- **JupyterLab**：专注 Notebook，界面直观，适合互探索。
- **终端**：负责安装软件、激活环境、启动 Jupyter 和运行 Python 脚本。

编辑器不是Python环境。无论使用VS Code还是 JupyterLab，都必须选择 `ai-science` 解释器或 Kernel。

## 2. 安装Conda：统一推荐 Miniforge

建议三个系统都安装 Miniforge。它体积较小，默认使用 `conda-forge`，也与本课程环境文件中的软件源保持一致。安装器可从 [Miniforge 官方发布页](https://github.com/conda-forge/miniforge/releases/latest) 获取。

已经安装 Miniconda 或 Anaconda 的同学不必重复安装，可以直接跳到第3节。

### 2.1 Windows

1. 下载 `Miniforge3-Windows-x86_64.exe`。
2. 双击安装，建议选择“Just Me”。
3. 安装位置尽量不要包含中文、空格或特殊字符。
4. 保留“Create start menu shortcuts”。初学者不必勾选“Add to PATH”，以免与系统中已有的 Python 冲突。
5. 安装完成后，从开始菜单打开 **Miniforge Prompt**。

在 Miniforge Prompt 中验证：

```bat
conda --version
conda info --envs
```

如果希望在 PowerShell 中使用 Conda，可运行：

```powershell
conda init powershell
```

然后关闭并重新打开 PowerShell 或 VS Code。

### 2.2 Linux

先检查处理器架构：

```bash
uname -m
```

常见输出为 `x86_64` 或 `aarch64`。下载对应的 Miniforge 安装脚本，例如 x86-64 Linux：

```bash
curl -L -O https://github.com/conda-forge/miniforge/releases/latest/download/Miniforge3-Linux-x86_64.sh
bash Miniforge3-Linux-x86_64.sh
```

按照提示完成安装，并同意初始化 Conda。随后重新打开终端，或执行：

```bash
source ~/.bashrc
```

若使用 Zsh，则运行：

```bash
conda init zsh
source ~/.zshrc
```

验证：

```bash
conda --version
conda info --envs
```

不需要使用 `sudo` 安装到系统目录；安装到自己的用户目录即可。

### 2.3 macOS

先检查 Mac 的处理器：

```bash
uname -m
```

- 输出 `arm64`：Apple Silicon，例如 M1、M2、M3、M4；
- 输出 `x86_64`：Intel Mac。

可以直接下载安装对应的 `.pkg`：

- Apple Silicon：`Miniforge3-MacOSX-arm64.pkg`；
- Intel：`Miniforge3-MacOSX-x86_64.pkg`。

也可以使用终端安装。Apple Silicon 示例：

```bash
curl -L -O https://github.com/conda-forge/miniforge/releases/latest/download/Miniforge3-MacOSX-arm64.sh
bash Miniforge3-MacOSX-arm64.sh
```

macOS 默认通常使用 Zsh：

```bash
conda init zsh
source ~/.zshrc
```

验证：

```bash
conda --version
conda info --envs
```

Apple Silicon 应优先安装原生 `arm64` 版本，不建议为了普通科学计算 Notebook 强制使用 Rosetta/x86-64 环境。

## 3. 建立 `ai-science` 环境

将以下三个文件放在同一个课程目录中：

```text
environment-ai-science.yml
check_ai_science_environment.py
课程中的各个 .ipynb 文件
```

在终端进入该目录。Windows 示例：

```bat
cd /d D:\AI-in-Science
```

Linux/macOS 示例：

```bash
cd ~/AI-in-Science
```

创建环境：

```bash
conda env create -f environment-ai-science.yml
```

激活环境：

```bash
conda activate ai-science
```

检查环境：

```bash
python check_ai_science_environment.py
```

如果环境已经存在，应更新而不是再次创建：

```bash
conda env update -n ai-science -f environment-ai-science.yml --prune
```

`--prune` 会删除环境中不再被 YAML 文件需要的 Conda 依赖。如果环境中有个人额外安装的软件包，更新前应先导出备份。

## 4. 日常使用Conda的一些命令

```bash
# 查看所有环境
conda env list

# 激活课程环境
conda activate ai-science

# 退出当前环境
conda deactivate

# 查看已安装软件包
conda list

# 在当前环境安装一个 Conda 包
conda install -c conda-forge seaborn

# 用当前 Python 对应的 pip 安装包
python -m pip install 包名

# 更新环境中的软件包索引和依赖
conda update --all
```

优先使用 Conda 安装 NumPy、SciPy 等带有底层二进制依赖的包。如果某个包在 Conda 中没有，再使用：

```bash
python -m pip install 包名
```

不要在已激活 `ai-science` 时直接使用不明确来源的 `pip`；`python -m pip` 能确保软件包安装到当前 Python 中。

## 5. 导出与分享环境

### 5.1 跨 Windows、Linux、macOS 分享：推荐方法

跨平台文件应只记录主动安装的顶层依赖，避免写入macOS或Windows专属的底层包：

```bash
conda export -n ai-science --from-history --format=environment-yaml --file=environment-from-history.yml
```

兼容旧版本 Conda 的命令为：

```bash
conda env export -n ai-science --from-history > environment-from-history.yml
```

注意：`--from-history` 很适合跨平台，但可能不会完整记录后来通过 pip 安装的包。因此课程中最好维护本指南附带的 `environment-ai-science.yml`，将必要的 pip 包明确写在 `pip:` 小节中。

### 5.2 当前机器的完整环境快照

完整 YAML 会记录所有 Conda 依赖和 pip 包，适合排查问题或在相同平台恢复：

```bash
conda export -n ai-science --format=environment-yaml --file=environment-full.yml
```

兼容旧版 Conda：

```bash
conda env export -n ai-science > environment-full.yml
```

完整文件经常包含平台专属包和构建编号，不适合直接从macOS复制到 Windows。

### 5.3 同一操作系统和硬件上的精确锁定

```bash
conda export -n ai-science --format=explicit --file=explicit.txt
```

这种文件包含精确的软件包地址，主要用于同平台复现，不适合跨系统共享。

### 5.4 单独导出pip软件包

```bash
conda activate ai-science
python -m pip freeze > requirements-pip.txt
```

恢复pip包：

```bash
python -m pip install -r requirements-pip.txt
```

`pip freeze` 会记录大量间接依赖，更适合备份，不建议把它作为学生第一次安装环境的唯一文件。

## 6. 导入环境

从跨平台 YAML 创建新环境：

```bash
conda env create -f environment-ai-science.yml
conda activate ai-science
```

如果希望使用另一个名字，以免覆盖现有环境：

```bash
conda env create -n ai-science-course -f environment-ai-science.yml
conda activate ai-science-course
```

从同平台精确文件创建环境：

```bash
conda create -n ai-science-copy --file explicit.txt
```

安装完成后都应运行：

```bash
python check_ai_science_environment.py
```

## 7. 注册 Jupyter Kernel

一般情况下 VS Code 和 JupyterLab能够自动发现 Conda 环境。为了让 Kernel 名称清晰，可以手动注册：

```bash
conda activate ai-science
python -m ipykernel install --user --name ai-science --display-name "Python (ai-science)"
```

查看 Kernel：

```bash
jupyter kernelspec list
```

如果曾经注册了错误的 Kernel，先查看准确名称，再删除：

```bash
jupyter kernelspec uninstall 错误的Kernel名称
```

## 8. 使用VS Code运行 `.ipynb`

### 8.1 安装组件

安装VS Code，然后在扩展市场安装：

- Python（Microsoft）；
- Jupyter（Microsoft）。

### 8.2 打开课程文件夹

选择 `File → Open Folder`，打开整个课程文件夹，而不是只打开一个孤立的 Notebook。这样相对路径、CSV 文件和图片更容易正确加载。

也可以从已经激活环境的终端启动：

```bash
conda activate ai-science
code .
```

### 8.3 选择 Python 与 Kernel

1. 按 `Ctrl+Shift+P`；macOS 为 `Cmd+Shift+P`。
2. 运行 `Python: Select Interpreter`，选择 `ai-science`。
3. 打开 `.ipynb`。
4. 点击右上角 `Select Kernel`。
5. 选择 `Python Environments → ai-science` 或 `Python (ai-science)`。

在第一个代码单元运行：

```python
import sys
print(sys.executable)
```

### 8.4 VS Code 中常用操作

| 操作 | 快捷键或入口 |
|---|---|
| 运行当前单元并移到下一单元 | `Shift+Enter` |
| 运行当前单元但停留在原处 | `Ctrl+Enter`；macOS 可用 `Cmd+Enter` |
| 保存 Notebook | `Ctrl+S` / `Cmd+S` |
| 命令面板 | `Ctrl+Shift+P` / `Cmd+Shift+P` |
| 运行全部单元 | Notebook 顶部 `Run All` |
| 重启 Kernel | Notebook 顶部 `Restart` |
| 清除全部输出 | 命令面板搜索 `Clear All Outputs` |

快捷键可能随 VS Code 的键位设置变化；可在 `Keyboard Shortcuts` 中搜索 `Notebook` 查看本机绑定。

## 9. 使用JupyterLab运行 `.ipynb`

在课程目录打开终端：

```bash
conda activate ai-science
jupyter lab
```

浏览器会自动打开 JupyterLab。双击 `.ipynb` 文件，并确认右上角 Kernel 为 `Python (ai-science)`。

停止服务器：回到启动 JupyterLab 的终端，按 `Ctrl+C`，必要时确认退出。

### 9.1 JupyterLab 的两种模式

- **编辑模式**：单元格边框通常为绿色，可以输入代码；按 `Enter` 进入。
- **命令模式**：单元格边框通常为蓝色，用于移动、删除或改变单元格类型；按 `Esc` 进入。

常用快捷键：

| 快捷键 | 功能 |
|---|---|
| `Shift+Enter` | 运行当前单元并选择下一单元 |
| `Ctrl+Enter` | 运行当前单元并停留 |
| `Alt+Enter` | 运行当前单元并在下方新建单元 |
| `Esc` / `Enter` | 进入命令模式 / 编辑模式 |
| `A` / `B` | 在上方 / 下方插入单元，需处于命令模式 |
| `M` / `Y` | 改为 Markdown / Code 单元，需处于命令模式 |
| `D,D` | 删除当前单元，需连续按两次 `D` |
| `Z` | 撤销删除单元 |
| `Ctrl+S` / `Cmd+S` | 保存 |
| `0,0` | 重启 Kernel，需连续按两次 `0` |

## 10. Notebook 中的重要基础知识

### 10.1 Code 单元与 Markdown 单元

Code 单元运行 Python：

```python
x = 3
x**2
```

Markdown 单元用于写说明、标题和公式：

```markdown
# 一级标题
## 二级标题

平均值定义为

$$
\bar{x}=\frac{1}{n}\sum_{i=1}^{n}x_i.
$$
```

Markdown 单元也要按 `Shift+Enter` 才会渲染。

### 10.2 单元执行顺序

左侧的 `[7]` 表示这是 Kernel 启动后第7次执行。Notebook 按“实际执行顺序”工作，而不是按页面从上到下自动工作。

提交作业前建议：

1. 保存文件；
2. `Restart Kernel`；
3. `Run All`；
4. 检查是否能从头到尾无错误运行。

如果重启后变量消失，说明前面某个必要单元没有运行，或代码依赖了混乱的执行顺序。

### 10.3 常用 IPython 命令

以 `%` 开头的是行魔法命令，以 `%%` 开头的是整个单元的魔法命令：

```python
%pwd                       # 当前工作目录
%cd 路径                   # 改变工作目录
%who                       # 查看已经定义的变量
%whos                      # 查看变量及其类型和大小
%time sum(range(1000000))  # 测量一条语句的时间
%timeit sum(range(1000))   # 多次运行并统计时间
%run example.py            # 运行 Python 文件
%matplotlib inline         # 在 Notebook 中显示 Matplotlib 图形
```

测量整个单元：

```python
%%time
total = 0
for i in range(1_000_000):
    total += i
```

安装软件包时，Notebook 中优先使用 `%pip` 或 `%conda`，它们比 `!pip` 更容易对应当前 Kernel：

```python
%pip install package_name
%conda install -c conda-forge package_name -y
```

安装完成后如果仍不能导入，应重启 Kernel。

以 `!` 开头可以临时运行系统命令：

```python
!python --version
```

不同系统的文件命令不同：Windows 常用 `!dir`，Linux/macOS 常用 `!ls`。为了让 Notebook 跨平台，处理文件时优先使用 Python 的 `pathlib`：

```python
from pathlib import Path

data_file = Path("data") / "materials_dielectric.csv"
print(data_file.resolve())
```

### 10.4 帮助和自动补全

```python
len?                 # 查看简要帮助
help(len)            # Python 帮助
pd.DataFrame?        # 查看对象说明
```

- 输入部分名称后按 `Tab`：自动补全；
- 在函数括号内按 `Shift+Tab`：查看参数提示；
- `object?`：查看文档；
- `object??`：在可能时查看更多实现信息。

## 11. 课程常用Python库导入方式

### 11.1 数值计算、表格和绘图

```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from scipy import stats
from scipy.integrate import solve_ivp
```

### 11.2 scikit-learn 通用工具

```python
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, PolynomialFeatures
from sklearn.impute import SimpleImputer
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    classification_report,
    mean_absolute_error,
    mean_squared_error,
    r2_score,
)
```

### 11.3 常用机器学习模型

```python
from sklearn.neighbors import KNeighborsClassifier, KNeighborsRegressor
from sklearn.linear_model import LinearRegression, Ridge, LogisticRegression, Perceptron
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor, plot_tree
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.svm import SVC, SVR
from sklearn.neural_network import MLPClassifier, MLPRegressor
```

### 11.4 材料科学接口

```python
from mp_api.client import MPRester
from emmet.core.summary import HasProps
from pymatgen.core import Composition, Structure
```

Materials Project 示例通常需要个人 API Key。不要把真实 Key 直接写入将要公开或提交到 Git 仓库的 Notebook。可以使用环境变量：

```python
import os
from mp_api.client import MPRester

api_key = os.getenv("MP_API_KEY")
with MPRester(api_key) as mpr:
    pass
```

### 11.5 绘图中文字体

如果图中中文显示为方框，可以先查看系统字体，然后选择已安装的中文字体：

```python
import matplotlib.pyplot as plt

plt.rcParams["font.sans-serif"] = [
    "SimSun",               # Windows 宋体
    "Microsoft YaHei",      # Windows 微软雅黑
    "Songti SC",            # macOS 宋体
    "Noto Sans CJK SC",     # Linux 常见中文字体
    "DejaVu Sans",
]
plt.rcParams["axes.unicode_minus"] = False
```

字体是否可用取决于操作系统；Conda 环境不能自动保证系统已经安装某一种中文字体。

## 12. `.py`、`.ipynb` 和 Markdown 的运行方式

运行普通 Python 文件：

```bash
conda activate ai-science
python example.py
```

打开 Notebook：

```bash
jupyter lab
```

将 Notebook 转换成可执行的 Python 脚本：

```bash
jupyter nbconvert --to script example.ipynb
```

在终端中从头执行 Notebook，并保存新的输出：

```bash
jupyter nbconvert --to notebook --execute example.ipynb --output example_executed.ipynb
```

Markdown 文件本身通常不“运行”，而是预览或渲染：

- VS Code：打开 `.md` 后按 `Ctrl+Shift+V`；macOS 为 `Cmd+Shift+V`；
- JupyterLab：可直接查看 Markdown，也可在 Notebook 的 Markdown 单元中书写；
- Markdown 中的代码块只负责展示，除非使用额外工具，否则不会自动执行。

## 13. 文件路径的跨平台写法

不要在课程 Notebook 中写死个人绝对路径，例如：

```python
# 不推荐
df = pd.read_csv("C:\\Users\\student\\Desktop\\materials.csv")
```

推荐把数据放在课程项目内，并使用 `pathlib`：

```python
from pathlib import Path
import pandas as pd

project_dir = Path.cwd()
data_path = project_dir / "data" / "materials_dielectric.csv"
df = pd.read_csv(data_path)
```

Notebook 的当前目录通常是启动 JupyterLab 的目录或 VS Code 工作区目录，可用以下命令确认：

```python
from pathlib import Path
print(Path.cwd())
```

## 14. 常见问题排查

### 14.1 `conda: command not found` 或“conda不是内部命令”

- Windows：使用开始菜单中的 Miniforge Prompt；
- Linux Bash：运行 `~/miniforge3/bin/conda init bash` 后重新打开终端；
- macOS Zsh：运行 `~/miniforge3/bin/conda init zsh` 后重新打开终端；
- 如果安装目录不是 `~/miniforge3`，应改成实际路径。

### 14.2 已安装包，但 Notebook 报 `ModuleNotFoundError`

先在 Notebook 中运行：

```python
import sys
print(sys.executable)
```

然后在终端运行：

```bash
conda activate ai-science
python -c "import sys; print(sys.executable)"
```

如果两个路径不同，说明 Notebook 选错了 Kernel。重新选择 `Python (ai-science)`。

### 14.3 `No module named ipykernel`

```bash
conda activate ai-science
conda install -c conda-forge ipykernel
python -m ipykernel install --user --name ai-science --display-name "Python (ai-science)"
```

### 14.4 Notebook 找不到 CSV 或图片

```python
from pathlib import Path

print("当前目录:", Path.cwd())
print("当前目录文件:", list(Path.cwd().iterdir()))
```

尽量从课程项目根目录启动 VS Code 或 JupyterLab，并使用相对路径。

### 14.5 环境创建时依赖冲突

先更新base中的 Conda：

```bash
conda activate base
conda update -n base conda
```

然后重新执行环境创建或更新命令。不要随意删除 `python=3.12` 约束；如果某个额外库暂不支持 Python 3.12，可以为该专题单独建立环境，而不是破坏课程公共环境。

### 14.6 Notebook一直显示 `*` 或 Kernel 无响应

`[*]` 表示单元正在运行。先等待计算完成；如果明显卡死：

1. 选择 `Interrupt Kernel`；
2. 若无效，选择 `Restart Kernel`；
3. 从头运行必要单元；
4. 检查是否存在无限循环、过大的数组或内存不足。

## 15. 最短操作清单

第一次配置：

```bash
conda env create -f environment-ai-science.yml
conda activate ai-science
python -m ipykernel install --user --name ai-science --display-name "Python (ai-science)"
python check_ai_science_environment.py
jupyter lab
```

以后每次上课或自己做练习时：

```bash
conda activate ai-science
jupyter lab
```

使用 VS Code时，打开 `.ipynb` 后再确认一次右上角 Kernel 是 `Python (ai-science)`。提交 Notebook 前执行一次 `Restart Kernel and Run All`，确保文档能够从空白状态完整复现。

## 参考资料

- [Conda：管理和分享环境](https://docs.conda.io/projects/conda/en/stable/user-guide/tasks/manage-environments.html)
- [Miniforge 官方安装说明](https://github.com/conda-forge/miniforge)
- [VS Code：Jupyter Notebook](https://code.visualstudio.com/docs/datascience/jupyter-notebooks)
- [VS Code：选择和管理 Jupyter Kernel](https://code.visualstudio.com/docs/datascience/jupyter-kernel-management)


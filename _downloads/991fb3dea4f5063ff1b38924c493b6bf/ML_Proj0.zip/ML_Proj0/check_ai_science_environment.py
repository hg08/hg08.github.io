"""Quick smoke test for the cross-platform ai-science environment."""

from __future__ import annotations

import importlib
import platform
import sys


PACKAGES = {
    "numpy": "NumPy",
    "pandas": "Pandas",
    "scipy": "SciPy",
    "matplotlib": "Matplotlib",
    "sklearn": "scikit-learn",
    "IPython": "IPython",
    "ipykernel": "ipykernel",
    "mp_api": "mp-api",
    "pymatgen": "pymatgen",
    "plotly": "Plotly",
}


def main() -> int:
    print(f"操作系统: {platform.platform()}")
    print(f"Python: {sys.version.split()[0]}")
    print(f"解释器: {sys.executable}")
    print("\n库导入检查:")

    failed: list[str] = []
    for module_name, display_name in PACKAGES.items():
        try:
            module = importlib.import_module(module_name)
            version = getattr(module, "__version__", "版本号未公开")
            print(f"  [OK] {display_name}: {version}")
        except Exception as exc:  # Show the real import error for troubleshooting.
            failed.append(display_name)
            print(f"  [FAIL] {display_name}: {exc}")

    if failed:
        print("\n检查未通过: " + ", ".join(failed))
        return 1

    print("\n环境检查通过，可以运行课程 Notebook。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


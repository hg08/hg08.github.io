# torch-study teaching environment

This is a portable *baseline* for macOS, Windows and Linux, not a fully locked, bit-for-bit identical environment. The instructor verified `torch==2.15.0` in a macOS Python 3.12 environment; installation still needs testing on each OS and architecture.

## Install

Install Miniforge/Conda, then in a terminal run:

```sh
conda env create -f environment.yml
conda activate torch-study
python -m ipykernel install --user --name torch-study --display-name "Python (torch-study)"
jupyter lab
```

Windows users: use Miniforge Prompt/Anaconda Prompt for these commands. In JupyterLab select the `Python (torch-study)` kernel.

## Sanity check

```sh
python -c "import numpy as np, torch, sklearn, matplotlib, pandas; x=np.array([1.,2.,3.],dtype=np.float32); print(torch.from_numpy(x)); print('torch:',torch.__version__)"
```

Check `torch.__version__` and that the NumPy array can be converted without errors.

## Special hardware

The baseline uses pip's platform-default torch wheel. CUDA/ROCm acceleration may require an OS- and driver-specific PyTorch wheel or separate install instructions: https://pytorch.org/get-started/locally/ . For consistent introductory lab results, use CPU first. `torch.backends.mps.is_available()` can be used to inspect supported Apple Silicon MPS machines.

## Maintenance and reproducibility

The `environment.yml` build strings, and local installation paths. Dependencies other than torch have bounded version ranges, so student environments will not necessarily have exactly the same patch versions. For an exact snapshot of the instructor's working environment, separately archive `python -m pip freeze > pip-freeze.txt` and `conda env export > environment-full.yml`; do not use the full export as the cross-platform class specification. The file was prepared from the described installed packages and successful test, not an automated read of the instructor's machine.
